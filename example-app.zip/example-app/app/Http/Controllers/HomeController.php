<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function index(){
        $arr1 = [1, 2, 3, 3, 8, 9];
        $arr2 = [8, 9, 4, 5, 6, 7, 1];
        //Output : [1,2,3,4,5,6,7,8,9]
        
       // $arr3 = array_merge($arr1,$arr2);
       // print_r($arr3);die;
       $c = count($arr2);
       $c1 = count($arr1)+count($arr2);
        $p=0;

       for($i=$c;$i<$c1;$i++){
        
        $arr2[$i]=$arr1[$p];
        $p++;
       }
       for($i=0;$i<count($arr2);$i++){
        for($j=0;$j<count($arr2)-1;$j++){
            if($arr2[$j]>$arr2[$j+1]){
                $temp = $arr2[$j];
                $arr2[$j] = $arr2[$j+1];
                $arr2[$j+1] = $temp;
            }
        }
       }
       echo "<pre>";
       print_r($arr2);
       $arr3[0]= $arr2[0];
       for($i=0;$i<count($arr2);$i++){
        for($j=0;$j<count($arr2)-1;$j++){
            
            if($arr2[$j]!=$arr2[$j+1]){
                $arr3[$j] = $arr2[$j+1];
            }
        }
       }
      
       echo "<pre>";
       print_r($arr3);die;
    }
}
